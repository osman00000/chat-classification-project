A simple chat conversation classifier based on zero-shot classification.
